// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "GameplayTagsManager.h"

struct WELEVEL_API FStateTags : public FGameplayTagNativeAdder
{
	FGameplayTag StateDead;

 
protected:
	//Called to register and assign the native tags
	virtual void AddTags() override
	{
		UGameplayTagsManager& Manager = UGameplayTagsManager::Get();
		
		StateDead = Manager.AddNativeGameplayTag(TEXT("State.Dead"));
	}

private:
	
	static FStateTags StateTags;
};

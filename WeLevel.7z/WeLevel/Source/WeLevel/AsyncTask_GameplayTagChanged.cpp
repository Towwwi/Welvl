// Fill out your copyright notice in the Description page of Project Settings.


#include "AsyncTask_GameplayTagChanged.h"

#include "GameplayTagContainer.h"

UAsyncTask_GameplayTagChanged* UAsyncTask_GameplayTagChanged::ListenForGameplayTagChange(FGameplayTag EffectGameplayTag,
	AActor* TargetActor)
{
	UAsyncTask_GameplayTagChanged* WaitForGameplayTagChanged  = NewObject<UAsyncTask_GameplayTagChanged>();
	OnGameplayTagChanged.Broadcast()

	return WaitForGameplayTagChanged;
}

void UAsyncTask_GameplayTagChanged::EndTask()
{
	SetReadyToDestroy();
	MarkAsGarbage();
}

void UAsyncTask_GameplayTagChanged::GameplayTagChanged()
{
	OnGameplayTagChanged.Broadcast()
}

// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "Kismet/BlueprintAsyncActionBase.h"
#include "AsyncTask_GameplayTagChanged.generated.h"

/**
 * 
 */

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnGameplayTagChanged, FGameplayTag, EffectGameplayTag, AActor*, TargetActor);

UCLASS(BlueprintType, meta = (ExposedAsyncProxy = AsyncTask))
class WELEVEL_API UAsyncTask_GameplayTagChanged : public UBlueprintAsyncActionBase
{
	GENERATED_BODY()

protected:

	UPROPERTY(BlueprintAssignable)
	FOnGameplayTagChanged OnGameplayTagChanged;

	UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true"))
	static UAsyncTask_GameplayTagChanged* ListenForGameplayTagChange(FGameplayTag EffectGameplayTag, AActor* TargetActor);

	UFUNCTION(BlueprintCallable)
	void EndTask();

	UFUNCTION()
	void GameplayTagChanged();
	
};
